using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [SerializeField, Tooltip("Nivel atual")]
    private int currentLevel; //nivel atual
    [SerializeField, Tooltip("Total de n�veis, 0 � o menu e o �ltimo � o Game Over")]
    private int totalLevels; //total de n�veis 0 - menu, totalLevels-1 - win, totalLevels - Game Over
    [SerializeField, Tooltip("Pontua��o")]
    private int score; //pontua��o obtida
    [SerializeField, Tooltip("Vida")]
    private int life;
    [SerializeField, Tooltip("Total de chaves")]
    private int keys; //chaves coletadas

    void Start()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); // Mant�m o objeto ao trocar de cena
        }
        else
        {
            Destroy(gameObject); // Evita m�ltiplas inst�ncias
        }
    }
    //inicia o jogo e defini os valores iniciais das vari�veis
    public void StartGame()
    {
        CurrentLevel = 1;
        TotalLevels = 3;
        Score = 0;
        keys = 0;
        Life = 3;
    }

    public int CurrentLevel
    {
        get { return currentLevel; }
        set { currentLevel = value; }
    }

    public int TotalLevels
    {
        get { return totalLevels; }
        set { totalLevels = value; }
    }

    public int Life
    {
        get { return life; }
        set { life = value; }
    }

    public void DecLife()
    {
        //vai para onde tem que ir
        // menu - mesma fase - GameOver
        Life--;
        keys = 0;
        if (life > 0) 
        {
            SceneManager.LoadScene(currentLevel);
        }
        else
        {
            SceneManager.LoadScene(totalLevels);
        }
    }

    public void IncLife()
    {
        if (life <3)
        {
            Life++;
        }
    }

    public int Score
    {
        get { return score; }
        set { score = value; }
    }


    //trabalhar com as chaves
    public void PutKey()
    {
        keys++;
    }

    public bool GetKey()
    {
        bool result = false;
        if (keys > 0) { 
            keys--; 
            result = true; 
        } 
        return result;
    }

    public bool HasKey()
    {
        return keys > 0;
    }

    public void GoToNextLevel()
    {
        currentLevel++;
        SceneManager.LoadScene(currentLevel);
    }
}
