using UnityEditor.ShaderGraph;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMoviment : MonoBehaviour
{
    //public float wallCheckDistance = 0.5f; // Distância para verificar se há parede
    //verifica se esta próximo da parede
    //bool isTouchingWall = false;

    [SerializeField,Tooltip("Velocidade máxima do jogador")]
    float moveSpeed = 7f;
    [SerializeField, Tooltip("Força do pulo do jogador")]
    float jumpForce = 12f;
    [SerializeField, Tooltip("Quantidade de pulos do jogador")]
    int maxJumps = 2;  
    private int jumpCount = 0;

    [SerializeField, Tooltip("Ponto 'Propriedade' do jogador utilizada para verificar se esta no chão")]
    Transform groundCheck;

    [SerializeField, Tooltip("Camada 'layer' que chão esta definido")]
    LayerMask groundLayer;

    private Animator anim;
    private Rigidbody2D rb;
    private Vector2 moveInput;

    //verifica se estano chão
    private bool isGrounded;
    //verifica se pulou
    private bool jumpPressed;

    //utilizado para capturar asentradas do usuário
    //precisa definir os tipos de inputaction no player
    public InputAction MoveAction;
    public InputAction JumpAction;

    private void OnDrawGizmos()
    {
        //mostra o groudcheck na tela
        Gizmos.color = Color.black;
        Gizmos.DrawSphere(groundCheck.position, 0.1f);
    }

    void Awake()
    {
        //define a animação
        anim = GetComponent<Animator>();
        //define o corpo rigido
        rb = GetComponent<Rigidbody2D>();
        //ativa o input action
        MoveAction.Enable();
        JumpAction.Enable();
    }

    
    void FixedUpdate()
    {
        

        //primeiro fazer aqui e depois criar os eventos Move e Jump
        //rb.linearVelocity = new Vector2(moveInput.x * moveSpeed, rb.linearVelocity.y);

        //para evitar travar na parede caso não use materiais 2d no rigidbody
        //if (isGrounded || !isTouchingWall)
        //{
        //    rb.linearVelocity = new Vector2(moveInput.x * moveSpeed, rb.linearVelocity.y);
        //}
    }

    void Update()
    {
        //verifica se esta no chão
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, 0.1f, groundLayer);
        
        // Ativar animação de andar
        anim.SetBool("isWalking", moveInput.x != 0f);

        Move();
        Jump();
    }

    private void Move()
    {
        //Entrada de dados
        moveInput = MoveAction.ReadValue<Vector2>();
        
        //virar para a direita ou esquerda
        Flip(moveInput.x);

        //andar mudando a velocidade do x e mantendo a do y para garantir que a gravidade e o pulo continuem funcionando sem interferências.
        rb.linearVelocity = new Vector2(moveInput.x * moveSpeed, rb.linearVelocity.y);
    }

    private void Jump()
    {
        //entrada de dados
        jumpPressed = JumpAction.WasPressedThisFrame();

        // reseta o pulo
        if (isGrounded)
        {
            jumpCount = 0;  // Reseta os pulos quando toca no chão
        }

        // pula
        if (jumpPressed && jumpCount < maxJumps)
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
            jumpPressed = false;
            jumpCount++;
        }
    }

    

    void Flip(float moveInput)
    {
        if (moveInput > 0)
        {
            transform.localScale = new Vector3(1, 1, 1);
        }
        if (moveInput < 0)
        {
            transform.localScale = new Vector3(-1, 1, 1);
        }
    }

}
