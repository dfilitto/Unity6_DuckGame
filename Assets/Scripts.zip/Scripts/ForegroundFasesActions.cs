using System.Collections;
using UnityEngine;
using UnityEngine.Tilemaps;

public class ForegroundFasesActions : MonoBehaviour
{
    private Tilemap tilemap;
    private Color originalColor;
    private Coroutine fadeCoroutine;

    public float fadeDuration = 1f; // Tempo da transi��o (1 segundo)
    public float targetAlpha = 0f; // Alpha quando o jogador entra

    void Start()
    {
        tilemap = GetComponent<Tilemap>();
        originalColor = tilemap.color;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            // Para evitar sobreposi��o de corrotinas, interrompe a anterior antes de iniciar uma nova
            if (fadeCoroutine != null) StopCoroutine(fadeCoroutine);
            fadeCoroutine = StartCoroutine(ChangeAlpha(originalColor.a, targetAlpha));
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            if (fadeCoroutine != null) StopCoroutine(fadeCoroutine);
            fadeCoroutine = StartCoroutine(ChangeAlpha(tilemap.color.a, originalColor.a));
        }
    }

    IEnumerator ChangeAlpha(float startAlpha, float endAlpha)
    {
        float elapsedTime = 0f;
        Color color = tilemap.color;

        while (elapsedTime < fadeDuration)
        {
            elapsedTime += Time.deltaTime;
            float newAlpha = Mathf.Lerp(startAlpha, endAlpha, elapsedTime / fadeDuration);
            color.a = newAlpha;
            tilemap.color = color;
            yield return null;
        }

        // Garante que o alpha final seja exatamente o esperado
        color.a = endAlpha;
        tilemap.color = color;
    }
}
