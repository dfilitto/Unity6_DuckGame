using UnityEngine;

public class ScrollingBackground : MonoBehaviour
{
    public float scrollSpeed = 0.5f;
    private Material mat;
    private Vector2 offset;

    void Start()
    {
        mat = GetComponent<Renderer>().material;
    }

    void Update()
    {
        offset.x += scrollSpeed * Time.deltaTime;

        // Resetando o offset para evitar distor��es
        if (offset.x >= 1f || offset.x <= -1f)
        {
            offset.x = 0f;
        }
        
        mat.mainTextureOffset = offset;
    }
}
