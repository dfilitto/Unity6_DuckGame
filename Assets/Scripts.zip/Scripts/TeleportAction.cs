using UnityEngine;

public class TeleportAction : MonoBehaviour
{
    [SerializeField, Tooltip("Destino do teleport")]
    Transform destine;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            collision.gameObject.transform.position = destine.position;
        }
    }
}
