using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerActions : MonoBehaviour
{
    public InputAction InteractionAction;
    bool interactionInput;
    AudioSource audioSource;
    
    private void Awake()
    {
        InteractionAction.Enable();
        audioSource = GetComponent<AudioSource>();
    }

    private void Update()
    {
        interactionInput = InteractionAction.IsPressed();
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Key")
        {
            GameManager.Instance.PutKey();
            Destroy(collision.gameObject);
        }

        if (collision.tag == "Door" && collision.GetComponent<DoorActions>().IsOpen() == false)
        {
            if (GameManager.Instance.GetKey())
            {
                //abrir a porta
                collision.GetComponent<DoorActions>().OpenDoor();
            }
        }

        if (collision.tag == "Heart")
        {
            GameManager.Instance.IncLife();
            Destroy(collision.gameObject);
        }


    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        

        if (collision.tag == "Door" && collision.GetComponent<DoorActions>().IsOpen() && interactionInput)
        {
            GameManager.Instance.GoToNextLevel();
        }
    }

    public void PlayDuckSound()
    {
        audioSource.Play();
    }
}
