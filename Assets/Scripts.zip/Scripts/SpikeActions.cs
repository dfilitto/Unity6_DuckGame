using UnityEngine;

public class SpikeActions : MonoBehaviour
{
    [SerializeField, Tooltip("Part�cula que ser� gerada")]
    public GameObject particlePrefab; // Refer�ncia ao prefab da part�cula
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            if (particlePrefab != null)
            {
                // Instancia a part�cula na posi��o do objeto
                //Instantiate(particlePrefab, transform.position, Quaternion.identity);

                AudioManager.instance.Play("Quack");
                //MATAR o player e reiniciar o game
                //collision.GetComponent<PlayerActions>().PlayDuckSound();
                Destroy(collision.gameObject);
                GameManager.Instance.DecLife();
                //Invoke("CheckLife", 0.5f);
            }
            else
            {
                Debug.LogWarning("Prefab de part�cula n�o atribu�do!");
            }
        }
    }
    private void CheckLife()
    {
        GameManager.Instance.DecLife();
    }
}
