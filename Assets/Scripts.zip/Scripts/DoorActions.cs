using UnityEngine;

public class DoorActions : MonoBehaviour
{
    GameObject textBubble;
    Animator anim;
    bool open = false;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        anim = GetComponent<Animator>();
        textBubble = GetComponent<GameObject>();
        textBubble = transform.GetChild(0).gameObject; //textBubble = transform.Find("NomeDoFilho")?.gameObject;
        textBubble.SetActive(false);
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (open && collision.tag=="Player") 
        {
            textBubble.SetActive(true);
        }
    }

    

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (open && collision.tag == "Player")
        {
            textBubble.SetActive(false);
        }
    }

    public void OpenDoor()
    {
        open = true;
        anim.SetBool("open", open);
        AudioManager.instance.Play("Unlock");
    }

    public void CloseDoor()
    {
        open = false;
        anim.SetBool("open", open);
    }

    public bool IsOpen()
    {
        return open;
    }

}
