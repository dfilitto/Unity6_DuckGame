using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuActions : MonoBehaviour
{
    public void Start()
    {
        AudioManager.instance.Play("GameMusic");
    }
    public void StartGame()
    {
        SceneManager.LoadScene(1);
        GameManager.Instance.StartGame();
    }

    public void ExitGame()
    {
        Application.Quit();
    }
}
