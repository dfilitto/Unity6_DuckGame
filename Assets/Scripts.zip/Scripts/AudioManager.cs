using System;
using UnityEngine;
using UnityEngine.Audio;

public class AudioManager : MonoBehaviour
{
    // Inst�ncia est�tica do AudioManager para garantir que exista apenas uma inst�ncia global
    public static AudioManager instance;

    // Array de sons que o AudioManager ir� controlar
    public Sound[] sounds;

    // Flag para mutar ou n�o os sons
    public bool mute = false;

    // Vari�vel para o volume global
    [Range(0f, 1f)]
    public float globalVolume = 1f; // Volume global padr�o (m�ximo)

    // M�todo chamado ao inicializar o script
    void Awake()
    {
        // Verifica se j� existe uma inst�ncia do AudioManager
        if (instance != null)
        {
            // Se j� existir, destr�i este objeto para garantir que haja apenas uma inst�ncia
            Destroy(gameObject);
        }
        else
        {
            // Se n�o existir, define esta inst�ncia como a inst�ncia global
            instance = this;
            // Faz com que o AudioManager persista entre cenas
            DontDestroyOnLoad(gameObject);
        }

        // Inicializa todas as fontes de �udio para cada som
        foreach (Sound s in sounds)
        {
            // Garantir que os valores est�o dentro dos limites
            s.volume = Mathf.Clamp(s.volume, 0f, 1f);
            s.pitch = Mathf.Clamp(s.pitch, -3f, 3f);

            // Adiciona um componente AudioSource ao GameObject atual
            s.source = gameObject.AddComponent<AudioSource>();
            // Atribui o clip de �udio correspondente ao AudioSource
            s.source.clip = s.clip;
            // Atribui o volume do AudioSource com base no volume global
            s.source.volume = s.volume * globalVolume;
            // Atribui o pitch do AudioSource
            s.source.pitch = s.pitch;
            // Atribui se o som ser� reproduzido em loop
            s.source.loop = s.loop;
        }
    }

    // M�todo para reproduzir um som espec�fico pelo nome
    public void Play(string sound)
    {
        // Verifica se o som n�o est� mutado
        if (!this.mute)
        {
            // Encontra o som correspondente pelo nome
            Sound s = Array.Find(sounds, item => item.name == sound);
            // Verifica se o som foi encontrado
            if (s != null)
            {
                //reproduz o som
                s.source.Play();
            }
            else
            {
                Debug.LogWarning("Som n�o encontrado: " + sound);
            }
        }
    }

    public void Stop(string sound)
    {
        if (!this.mute)
        {
            // Encontra o som correspondente
            Sound s = Array.Find(sounds, item => item.name == sound);

            if (s != null)
            {
                s.source.Stop();
            }
            else
            {
                Debug.LogWarning("Som n�o encontrado: " + sound);
            }
        }
    }

    public void SetVolume(float volume)
    {
        // Atualiza o volume global
        globalVolume = volume;

        // Atualiza o volume de cada som com base no volume global
        foreach (Sound s in sounds)
        {
            s.source.volume = s.volume * globalVolume;
        }
    }

    public void ToggleMute()
    {
        mute = !mute;

        // Ajusta o volume dos sons de acordo com o estado do mute
        foreach (Sound s in sounds)
        {
            s.source.volume = mute ? 0f : s.volume * globalVolume; // Se estiver mudo, coloca o volume como 0
        }
    }
}
