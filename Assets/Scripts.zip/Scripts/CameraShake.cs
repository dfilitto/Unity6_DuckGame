using System.Collections;
using Unity.Cinemachine;
using UnityEngine;

public class CameraShake : MonoBehaviour
{
    public static CameraShake Instance { get; private set; }

    public float shakeDuration = 0.2f;
    public float shakeMagnitude = 0.2f;

    private Vector3 originalPos;
    private float remainingShakeTime = 0f;

    void Awake()
    {
        // Garante que s� exista uma inst�ncia
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        originalPos = transform.position;
    }

    void Update()
    {
        if (remainingShakeTime > 0)
        {
            transform.position = originalPos + (Vector3)Random.insideUnitCircle * shakeMagnitude;
            remainingShakeTime -= Time.deltaTime;
        }
        else
        {
            transform.position = originalPos;
        }
    }

    public void TriggerShake()
    {
        remainingShakeTime = shakeDuration;
    }
}
