using UnityEngine;
using UnityEngine.UI;

public class HudActions : MonoBehaviour
{
    [SerializeField, Tooltip("Life")]
    RectTransform imageLife; // Refer�ncia ao RectTransform da imagem
    [SerializeField, Tooltip("Keys")]
    Image keyImage;

    // Update is called once per frame
    void Update()
    {
        //exibe a quantidade de vida
        int life = GameManager.Instance.Life;
        imageLife.sizeDelta = new Vector2(68*life, 68);
        //verifica se tem a key
        Color color = keyImage.color;
        color.a = 0; // Garante que o alpha fique entre 0 e 1     
        if (GameManager.Instance.HasKey())
        {
            color.a = 1;
        }
        keyImage.color = color;
    }
}
