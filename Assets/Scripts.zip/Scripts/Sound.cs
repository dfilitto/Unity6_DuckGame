﻿using UnityEngine;

// Classe responsável por armazenar e configurar propriedades de sons no Unity
[System.Serializable]
public class Sound
{

    // Nome do som (utilizado para identificação)
    public string name;

    // O clip de áudio que será reproduzido
    public AudioClip clip;

    // Volume do som (valor entre 0 e 1)
    [Range(0f, 1f)]
    public float volume;

    // Pitch (afinação) do som (valor entre -3 e 3)
    [Range(-3f, 3f)]
    public float pitch;

    // Define se o som será repetido em loop (padrão é false)
    public bool loop = false;

    // Fonte de áudio associada ao som. Não visível no editor, pois é atribuída em tempo de execução.
    [HideInInspector]
    public AudioSource source;

}