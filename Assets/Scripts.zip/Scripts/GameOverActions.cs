using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOverActions : MonoBehaviour
{
    [SerializeField]
    TextMeshProUGUI txtMessage;
    [SerializeField]
    GameObject family;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        AudioManager.instance.Stop("GameMusic");
        AudioManager.instance.Play("GameOver");
        if (GameManager.Instance.Life > 0)
        {
            txtMessage.text = "YOU WIN!!!!!!";
        }
        else
        {
            txtMessage.text = "YOU LOSE!!!!!!";
            family.SetActive(false);
        }
        Invoke("RestartGame",5f);
    }

    // Update is called once per frame
    void RestartGame()
    {
        SceneManager.LoadScene(0);
    }
}
